# Victor Manuel Ayala Silva - Miguel Angel Romero Peña

import math
import matplotlib.pyplot as plt
import numpy as np

def caracterizar_triangulo(lado1, lado2, lado3):
    # Verificar si los lados forman un triángulo
    if (lado1 + lado2 <= lado3) or (lado1 + lado3 <= lado2) or (lado2 + lado3 <= lado1):
        return "Los lados no forman un triángulo."
    
    # Cálculo de los ángulos usando la ley de cosenos
    angulo1 = math.degrees(math.acos((lado2**2 + lado3**2 - lado1**2) / (2 * lado2 * lado3)))
    angulo2 = math.degrees(math.acos((lado1**2 + lado3**2 - lado2**2) / (2 * lado1 * lado3)))
    angulo3 = 180 - angulo1 - angulo2  # Suma de ángulos en un triángulo es 180 grados

    # Definir la clasificación del Triangulo

    # Lados
    if lado1 == lado2 == lado3:
        tipoLado = "Equilátero"
    elif lado1 == lado2 or lado1 == lado3 or lado2 == lado3:
        tipoLado = "Isósceles"
    else:
        tipoLado = "Escaleno"
    
    # Angulos
    if angulo1 == 90 or angulo2 == 90 or angulo3 == 90:
        tipoAngulo = "Rectángulo"

    elif angulo1 < 90 and angulo2 < 90 and angulo3 < 90:
        tipoAngulo = "Acutángulo"
    
    elif angulo1 > 90 or angulo2 > 90 or angulo3 > 90:
        tipoAngulo = "Obtusángulo"


    return angulo1, angulo2, angulo3, tipoLado, tipoAngulo

def graficar_triangulo(lado1, lado2, lado3):
    angulo1, angulo2, angulo3, tipoLado, tipoAngulo= caracterizar_triangulo(lado1, lado2, lado3)
    
    # Coordenadas del triángulo
    A = np.array([0, 0])
    B = np.array([lado1, 0])  # El vértice B está en el eje X
    
    # Usamos coordenadas polares para calcular el tercer vértice C
    # C = (x, y) es el vértice desconocido
    # Usamos la ley de cosenos para calcular las coordenadas de C
    x_c = lado2 * np.cos(np.radians(angulo3))
    y_c = lado2 * np.sin(np.radians(angulo3))
    C = np.array([x_c, y_c])
    
    # Crear el gráfico
    fig, ax = plt.subplots()
    ax.plot([A[0], B[0]], [A[1], B[1]], label=f"Lado 1: {lado1:.2f}", color="blue")
    ax.plot([C[0], A[0]], [C[1], A[1]], label=f"Lado 2: {lado2:.2f}", color="green")
    ax.plot([B[0], C[0]], [B[1], C[1]], label=f"Lado 3: {lado3:.2f}", color="red")

    
    # Etiquetas de los vértices
    ax.text(A[0], A[1], 'A', fontsize=12, ha='right')
    ax.text(B[0], B[1], 'B', fontsize=12, ha='left')
    ax.text(C[0], C[1], 'C', fontsize=12, ha='center', va='bottom')
    
    # Ángulos en cada vértice
    ax.text(A[0], A[1] + 1, f"{angulo1:.2f}°", fontsize=12, ha='center')
    ax.text(B[0], B[1] + 1, f"{angulo2:.2f}°", fontsize=12, ha='center')
    ax.text(C[0], C[1] - 1, f"{angulo3:.2f}°", fontsize=12, ha='center')

    # Configuración de la visualización
    ax.set_aspect('equal')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_title(f'Triángulo {tipoLado} {tipoAngulo}')
    ax.grid(True)
    ax.legend()
    
    plt.show()

# Solicitar al usuario que ingrese los lados del triángulo
while True:
    try:
        lado1 = float(input("Ingrese el primer lado del triángulo: "))
        lado2 = float(input("Ingrese el segundo lado del triángulo: "))
        lado3 = float(input("Ingrese el tercer lado del triángulo: "))
    
        angulo1, angulo2, angulo3, tipoLado, tipoAngulo = caracterizar_triangulo(lado1, lado2, lado3)
        print(f"Ángulos del triángulo: {angulo1:.2f}, {angulo2:.2f}, {angulo3:.2f}")
        print(f"El triángulo es {tipoLado} y {tipoAngulo}")

        # Graficar el triángulo
        graficar_triangulo(lado1, lado2, lado3)

        break

    except:
        print("Por favor, ingrese valores numéricos válidos.")